
package ProyectoFinal;

public class Producto {
    private String nombre;
    private int cantidad;
    private double precio;

    public Producto(String nombre, int cantidad, double precio) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "nombre='" + nombre + '\'' +
                ", cantidad=" + cantidad +
                ", precio=" + precio +
                '}';
    }

    public String aLineaTexto() {
        return nombre + "," + cantidad + "," + precio;
    }

    public static Producto desdeLineaTexto(String linea) {
        String[] partes = linea.split(",");
        String nombre = partes[0];
        int cantidad = Integer.parseInt(partes[1]);
        double precio = Double.parseDouble(partes[2]);
        return new Producto(nombre, cantidad, precio);
    }
}

