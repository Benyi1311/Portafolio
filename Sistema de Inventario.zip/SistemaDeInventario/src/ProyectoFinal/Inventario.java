
package ProyectoFinal;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Inventario {
    List<Producto> productos;
    private static final String ARCHIVODEINVENTARIO = "inventario.txt";

    public Inventario() {
        this.productos = new ArrayList<>();
        cargarDesdeArchivo();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
        guardarEnArchivo();
    }

    public void eliminarProducto(String nombre) {
        productos.removeIf(producto -> producto.getNombre().equalsIgnoreCase(nombre));
        guardarEnArchivo();
    }

    public Producto buscarProducto(String nombre) {
        for (Producto producto : productos) {
            if (producto.getNombre().equalsIgnoreCase(nombre)) {
                return producto;
            }
        }
        return null;
    }

    public void mostrarProductos() {
        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }

    private void guardarEnArchivo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVODEINVENTARIO))) {
            for (Producto producto : productos) {
                writer.write(producto.aLineaTexto());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al guardar en el archivo: " + e.getMessage());
        }
    }

    private void cargarDesdeArchivo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVODEINVENTARIO))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                productos.add(Producto.desdeLineaTexto(linea));
            }
        } catch (IOException e) {
            System.out.println("Error al cargar desde el archivo: " + e.getMessage());
        }
    }
}

