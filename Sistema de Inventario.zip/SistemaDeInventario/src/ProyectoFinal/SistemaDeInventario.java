package ProyectoFinal;

import javax.swing.JOptionPane;

public class SistemaDeInventario {
    private static Usuario usuario;
    private static Inventario inventario;

    public static void main(String[] args) {
        usuario = new Usuario("admin", "password");
        inventario = new Inventario();

        boolean loginExitoso = false;

        while (!loginExitoso) {
            String nombreUsuario = JOptionPane.showInputDialog("Usuario:");
            String contrasena = JOptionPane.showInputDialog("Contraseña:");

            if (usuario.getNombreUsuario().equals(nombreUsuario) && usuario.verificarContrasena(contrasena)) {
                loginExitoso = true;
                JOptionPane.showMessageDialog(null, "¡Login exitoso!");
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos. Inténtalo de nuevo.");
            }
        }

        boolean continuar = true;

        while (continuar) {
            String[] opciones = {"Agregar producto", "Eliminar producto", "Buscar producto", "Mostrar todos los productos", "Salir"};
            int opcion = JOptionPane.showOptionDialog(null, "Selecciona una opción", "Sistema de Inventario",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

            switch (opcion) {
                case 0:
                    String nombre = JOptionPane.showInputDialog("Nombre del producto:");
                    int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad:"));
                    double precio = Double.parseDouble(JOptionPane.showInputDialog("Precio:"));

                    Producto producto = new Producto(nombre, cantidad, precio);
                    inventario.agregarProducto(producto);
                    JOptionPane.showMessageDialog(null, "Producto agregado.");
                    break;
                case 1:
                    nombre = JOptionPane.showInputDialog("Nombre del producto a eliminar:");
                    inventario.eliminarProducto(nombre);
                    JOptionPane.showMessageDialog(null, "Producto eliminado.");
                    break;
                case 2:
                    nombre = JOptionPane.showInputDialog("Nombre del producto a buscar:");
                    producto = inventario.buscarProducto(nombre);
                    if (producto != null) {
                        JOptionPane.showMessageDialog(null, producto.toString());
                    } else {
                        JOptionPane.showMessageDialog(null, "Producto no encontrado.");
                    }
                    break;
                case 3:
                    StringBuilder productosList = new StringBuilder();
                    for (Producto p : inventario.productos) {
                        productosList.append(p.toString()).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, productosList.toString());
                    break;
                case 4:
                    continuar = false;
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Inténtalo de nuevo.");
                    break;
            }
        }
    }
}

