package com.mycompany.models;

public class Buys {
    private int id;
    private int client_id;
    private int auto_id;
    private String date_buy;
    private float precio;

    public int getId() {
        return id;
    }

    public int getClient_id() {
        return client_id;
    }

    public int getAuto_id() {
        return auto_id;
    }

    public String getDate_buy() {
        return date_buy;
    }

    public float getPrecio() {
        return precio;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    public void setAuto_id(int auto_id) {
        this.auto_id = auto_id;
    }

    public void setDate_buy(String date_buy) {
        this.date_buy = date_buy;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }


}
