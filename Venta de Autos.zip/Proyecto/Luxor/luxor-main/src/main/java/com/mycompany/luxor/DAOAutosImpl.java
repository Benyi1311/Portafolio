package com.mycompany.luxor;

import com.mycompany.db.Database;
import com.mycompany.models.Autos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOAutos;

public class DAOAutosImpl extends Database implements DAOAutos {

    @Override
    public void registrar(Autos auto) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO autos(marca, modelo, año, motor, combustible, color, transmision, descripcion, kilometraje, precio, disponible) VALUES(?,?,?,?,?,?,?,?,?,?,?);");
            st.setString(1, auto.getMarca());
            st.setString(2, auto.getModelo());
            st.setString(3, auto.getAño());
            st.setString(4, auto.getMotor());
            st.setString(5, auto.getCombustible());
            st.setString(6, auto.getColor());
            st.setString(7, auto.getTransmision());
            st.setString(8, auto.getDescripcion());
            st.setFloat(9, auto.getKilometraje());
            st.setFloat(10, auto.getPrecio());
            st.setInt(11, auto.getDisponible());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Autos auto) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE autos SET marca = ?, modelo = ?, año = ?, motor = ?, combustible = ?, color = ?, transmision = ?, descripcion = ?, kilometraje = ?, precio = ?, disponible = ? WHERE id = ?");
            st.setString(1, auto.getMarca());
            st.setString(2, auto.getModelo());
            st.setString(3, auto.getAño());
            st.setString(4, auto.getMotor());
            st.setString(5, auto.getCombustible());
            st.setString(6, auto.getColor());
            st.setString(7, auto.getTransmision());
            st.setString(8, auto.getDescripcion());
            st.setFloat(9, auto.getKilometraje());
            st.setFloat(10, auto.getPrecio());
            st.setInt(11, auto.getDisponible());
            st.setInt(12, auto.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(int autoId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM autos WHERE id = ?;");
            st.setInt(1, autoId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Autos> listar(String marca) throws Exception {
        List<Autos> lista = null;
        try {
            this.Conectar();
            String Query = marca.isEmpty() ? "SELECT * FROM autos;" : "SELECT * FROM autos WHERE marca LIKE '%" + marca + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Autos auto = new Autos();
                auto.setId(rs.getInt("id"));
                auto.setMarca(rs.getString("marca"));
                auto.setModelo(rs.getString("modelo"));
                auto.setAño(rs.getString("año"));
                auto.setMotor(rs.getString("motor"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setColor(rs.getString("color"));
                auto.setTransmision(rs.getString("transmision"));
                auto.setDescripcion(rs.getString("descripcion"));
                auto.setKilometraje(rs.getFloat("kilometraje"));
                auto.setPrecio(rs.getFloat("precio"));
                auto.setDisponible(rs.getInt("disponible"));
                lista.add(auto);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Autos getAutoById(int autoId) throws Exception {
        Autos auto = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM autos WHERE id = ? LIMIT 1;");
            st.setInt(1, autoId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                auto = new Autos();
                auto.setId(rs.getInt("id"));
                auto.setMarca(rs.getString("marca"));
                auto.setModelo(rs.getString("modelo"));
                auto.setAño(rs.getString("año"));
                auto.setMotor(rs.getString("motor"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setColor(rs.getString("color"));
                auto.setTransmision(rs.getString("transmision"));
                auto.setDescripcion(rs.getString("descripcion"));
                auto.setKilometraje(rs.getFloat("kilometraje"));
                auto.setPrecio(rs.getFloat("precio"));
                auto.setDisponible(rs.getInt("disponible"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return auto;
    }   
}