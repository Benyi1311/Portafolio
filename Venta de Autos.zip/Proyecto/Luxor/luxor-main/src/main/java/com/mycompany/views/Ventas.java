package com.mycompany.views;

import com.mycompany.interfaces.DAOAutos;
import com.mycompany.luxor.DAOBuysImpl;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import com.mycompany.interfaces.DAOBuys;
import com.mycompany.luxor.DAOAutosImpl;
import com.mycompany.luxor.DAOClientsImpl;
import com.mycompany.utils.Utils;
import com.mycompany.interfaces.DAOClients;


public class Ventas extends javax.swing.JPanel {

    public Ventas() {
        initComponents();
        InitStyles();
        LoadBuys();
    }
    
    private void InitStyles() {
        folioLbl.putClientProperty("FlatLaf.styleClass", "large");
        folioLbl.setForeground(Color.black);
        libroIdLbl.putClientProperty("FlatLaf.styleClass", "large");
        libroIdLbl.setForeground(Color.black);
        clienteIdTxt.putClientProperty("JTextField.placeholderText", "Ingrese el ID del Cliente.");
        autoIdTxt.putClientProperty("JTextField.placeholderText", "Ingrese el ID del Auto a comprar.");
        title.putClientProperty("FlatLaf.styleClass", "h1");
        title.setForeground(Color.black);
        title1.putClientProperty("FlatLaf.styleClass", "h1");
        title1.setForeground(Color.black);
    }
    
    private void LoadBuys() {
        try {
            DAOBuys dao = new DAOBuysImpl();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            dao.listar().forEach((u) -> model.addRow(new Object[]{u.getClient_id(), u.getAuto_id(), u.getPrecio(), u.getDate_buy()}));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        autoIdTxt = new javax.swing.JTextField();
        button = new javax.swing.JButton();
        folioLbl = new javax.swing.JLabel();
        clienteIdTxt = new javax.swing.JTextField();
        libroIdLbl = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        title1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(750, 430));

        bg.setBackground(new java.awt.Color(255, 255, 255));

        title.setText("Reporte de ventas");

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Actualizar");
        jButton2.setBorderPainted(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "User ID", "Auto ID", "Precio de Venta", "Fecha de Venta"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Float.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jTable1.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                jTable1InputMethodTextChanged(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        autoIdTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autoIdTxtActionPerformed(evt);
            }
        });

        button.setBackground(new java.awt.Color(0, 0, 0));
        button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        button.setForeground(new java.awt.Color(255, 255, 255));
        button.setText("Vender");
        button.setBorderPainted(false);
        button.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonActionPerformed(evt);
            }
        });

        folioLbl.setText("Cliente ID");

        clienteIdTxt.setToolTipText("");

        libroIdLbl.setText("Auto ID");

        jSeparator1.setForeground(new java.awt.Color(204, 204, 204));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setPreferredSize(new java.awt.Dimension(200, 10));

        title1.setText("Aqui registra las ventas");

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(libroIdLbl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(title1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
                    .addComponent(clienteIdTxt, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(autoIdTxt, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(button, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(folioLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                    .addComponent(title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(41, 41, 41))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(title1)
                                .addGap(29, 29, 29)
                                .addComponent(folioLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                                .addGap(16, 16, 16)
                                .addComponent(clienteIdTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(libroIdLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                                .addGap(16, 16, 16)
                                .addComponent(autoIdTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(bgLayout.createSequentialGroup()
                                .addComponent(title)
                                .addGap(36, 36, 36)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addGap(25, 25, 25))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1InputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTable1InputMethodTextChanged
        //nothing
    }//GEN-LAST:event_jTable1InputMethodTextChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        LoadBuys();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void autoIdTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autoIdTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_autoIdTxtActionPerformed

    private void buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonActionPerformed
        String clienteId = clienteIdTxt.getText();
        String autoId = autoIdTxt.getText();

        if (clienteId.isEmpty() || autoId.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Debe llenar todos los campos. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
            clienteIdTxt.requestFocus();
            return;
        } else if (!Utils.isNumeric(clienteId) || !Utils.isNumeric(autoId)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Los campos ID del usuario y el ID del libro deben ser números enteros. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
            clienteIdTxt.requestFocus();
            return;
        } else if (Integer.parseInt(clienteId) <= 0 || Integer.parseInt(autoId) <= 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Los campos ID del usuario y el ID del libro deben ser mayor que 0. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
            clienteIdTxt.requestFocus();
            return;
        }

        try {
            DAOClients daoClients = new DAOClientsImpl();

            com.mycompany.models.Clients currentClient = daoClients.getClientById(Integer.parseInt(clienteId));
            if (currentClient == null) {
                javax.swing.JOptionPane.showMessageDialog(this, "No se encontró ningún usuario con ese ID. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
                clienteIdTxt.requestFocus();
                return;
            }

            DAOAutos daoAutos = new DAOAutosImpl();

            com.mycompany.models.Autos currentAuto = daoAutos.getAutoById(Integer.parseInt(autoId));
            if (currentAuto == null){
                javax.swing.JOptionPane.showMessageDialog(this, "No se encontró ningún auto con ese ID. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
                autoIdTxt.requestFocus();
                return;
            }
            else if (currentAuto.getDisponible() < 1) {
                javax.swing.JOptionPane.showMessageDialog(this, "Ya no hay más autos disponibles con esa ID para comprar. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
                autoIdTxt.requestFocus();
                return;
            }

            DAOBuys daoBuys = new DAOBuysImpl();
            
            float precioAuto = currentAuto.getPrecio();


  
            com.mycompany.models.Buys buy = new com.mycompany.models.Buys();
            buy.setAuto_id(currentAuto.getId());
            buy.setClient_id(currentClient.getId());
            buy.setDate_buy(Utils.getFechaActual());
            daoBuys.registrar(buy);

            currentAuto.setDisponible(currentAuto.getDisponible() - 1);
            daoAutos.modificar(currentAuto);
            


            

            javax.swing.JOptionPane.showMessageDialog(this, "Auto Marca: " + currentAuto.getMarca() + " comprado exitosamente por " + currentClient.getName() + ".\n", "AVISO", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            clienteIdTxt.setText("");
            autoIdTxt.setText("");
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ocurrió un error al comprar el auto. \n", "AVISO", javax.swing.JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_buttonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField autoIdTxt;
    private javax.swing.JPanel bg;
    private javax.swing.JButton button;
    private javax.swing.JTextField clienteIdTxt;
    private javax.swing.JLabel folioLbl;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel libroIdLbl;
    private javax.swing.JLabel title;
    private javax.swing.JLabel title1;
    // End of variables declaration//GEN-END:variables
}