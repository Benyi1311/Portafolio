package com.mycompany.models;

public class Proveedores {
    private int id;
    private String name;
    private String address;
    private String email;
    private String productos_supplied;
    private String payment_conditions;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getProductos_supplied() {
        return productos_supplied;
    }

    public String getPayment_conditions() {
        return payment_conditions;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setProductos_supplied(String productos_supplied) {
        this.productos_supplied = productos_supplied;
    }

    public void setPayment_conditions(String payment_conditions) {
        this.payment_conditions = payment_conditions;
    }
    
    
    
}
