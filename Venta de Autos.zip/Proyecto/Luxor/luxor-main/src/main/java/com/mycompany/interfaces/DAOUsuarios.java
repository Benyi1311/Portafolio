package com.mycompany.interfaces;

import com.mycompany.models.Usuarios;
import java.util.List;

public interface DAOUsuarios {
    public boolean validarUsuario(String username, String password);
    public void registrar(Usuarios usuario) throws Exception;
    public void modificar(Usuarios usuario) throws Exception;
    public void eliminar(int usuarioId) throws Exception;
    public List<Usuarios> listar(String username) throws Exception;
    public Usuarios getUsuarioById(int usuarioId) throws Exception;
}
