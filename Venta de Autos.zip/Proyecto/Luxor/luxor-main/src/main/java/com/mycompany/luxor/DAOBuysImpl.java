package com.mycompany.luxor;

import com.mycompany.db.Database;
import com.mycompany.models.Autos;
import com.mycompany.models.Buys;
import com.mycompany.models.Clients;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOBuys;

public class DAOBuysImpl extends Database implements DAOBuys {

    @Override
    public void registrar(Buys buy) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO buys(client_id, auto_id, date_buy) VALUES(?,?,?);");
            st.setInt(1, buy.getClient_id());
            st.setInt(2, buy.getAuto_id());
            st.setString(3, buy.getDate_buy());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Buys buy) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE buys SET client_id = ?, auto_id = ?, date_buy = ? WHERE id = ?");
            st.setInt(1, buy.getClient_id());
            st.setInt(2, buy.getAuto_id());
            st.setString(3, buy.getDate_buy());
            st.setInt(4, buy.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }    
    }

    @Override
    public Buys getBuy(Clients client, Autos auto) throws Exception {
        Buys buy = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT b.*, a.precio FROM buys b " +"JOIN autos a ON b.auto_id = a.id " +"WHERE b.client_id = ? AND b.auto_id = ? AND b.date_buy IS NULL " +"ORDER BY b.id DESC LIMIT 1");
            st.setInt(1, client.getId());
            st.setInt(2, auto.getId());
            
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                buy = new Buys();
                buy.setId(rs.getInt("id"));
                buy.setClient_id(rs.getInt("user_id"));
                buy.setAuto_id(rs.getInt("auto_id"));
                buy.setDate_buy(rs.getString("date_buy"));
                float precio = rs.getFloat("precio"); 
                buy.setPrecio(precio); 
            }
            
            st.close();
            rs.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        
        return buy;    
    }

    @Override
    public List<Buys> listar() throws Exception {
        List<Buys> lista = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT b.*, a.precio FROM buys b " +"JOIN autos a ON b.auto_id = a.id " +"ORDER BY b.id DESC");
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Buys buy = new Buys();
                buy.setId(rs.getInt("id"));
                buy.setClient_id(rs.getInt("client_id"));
                buy.setAuto_id(rs.getInt("auto_id"));
                buy.setDate_buy(rs.getString("date_buy"));
                float precio = rs.getFloat("precio");
                buy.setPrecio(precio);
                lista.add(buy);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;    
    }
    
    @Override    
    public float obtenerVentasDia() throws Exception {
        float totalVentas = 0;
        String query = "SELECT SUM(a.precio) FROM buys b "
                     + "JOIN autos a ON b.auto_id = a.id "
                     + "WHERE STR_TO_DATE(b.date_buy, '%d-%m-%Y') = CURDATE();";

        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                totalVentas = rs.getFloat(1);
            }
            st.close();
            rs.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return totalVentas;
    }

    
    @Override    
    public float obtenerVentasSemana() throws Exception {
        float totalVentas = 0;
        String query = "SELECT SUM(a.precio) FROM buys b "
                     + "JOIN autos a ON b.auto_id = a.id "
                     + "WHERE YEARWEEK(STR_TO_DATE(b.date_buy, '%d-%m-%Y'), 1) = YEARWEEK(CURDATE(), 1);";

        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                totalVentas = rs.getFloat(1);
            }
            st.close();
            rs.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return totalVentas;
    }


    @Override    
    public float obtenerVentasMes() throws Exception {
        float totalVentas = 0;
        String query = "SELECT SUM(a.precio) FROM buys b "
                     + "JOIN autos a ON b.auto_id = a.id "
                     + "WHERE MONTH(STR_TO_DATE(b.date_buy, '%d-%m-%Y')) = MONTH(CURDATE());";

        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                totalVentas = rs.getFloat(1);
            }
            st.close();
            rs.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return totalVentas;
    }


    @Override    
    public float obtenerVentasAnio() throws Exception {
        float totalVentas = 0;
        String query = "SELECT SUM(a.precio) FROM buys b "
                     + "JOIN autos a ON b.auto_id = a.id "
                     + "WHERE YEAR(STR_TO_DATE(b.date_buy, '%d-%m-%Y')) = YEAR(CURDATE());";

        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement(query);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                totalVentas = rs.getFloat(1);
            }
            st.close();
            rs.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return totalVentas;
    }
  
}
