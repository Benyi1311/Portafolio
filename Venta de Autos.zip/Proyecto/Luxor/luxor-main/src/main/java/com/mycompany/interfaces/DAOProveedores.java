package com.mycompany.interfaces;

import com.mycompany.models.Proveedores;
import java.util.List;

public interface DAOProveedores {
    public void registrar(Proveedores proveedor) throws Exception;
    public void modificar(Proveedores proveedor) throws Exception;
    public void eliminar(int proveedorId) throws Exception;
    public List<Proveedores> listar(String name) throws Exception;
    public Proveedores getProveedorById(int proveedorId) throws Exception;
}
