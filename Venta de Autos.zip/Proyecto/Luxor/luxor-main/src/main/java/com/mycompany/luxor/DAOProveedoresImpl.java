package com.mycompany.luxor;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOProveedores;
import com.mycompany.models.Proveedores;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class DAOProveedoresImpl extends Database implements DAOProveedores {
    
    @Override
    public void registrar(Proveedores proveedor) throws Exception{
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO proveedores(name, address, email, productos_supplied, payment_conditions) VALUES(?,?,?,?,?);");
            st.setString(1, proveedor.getName());
            st.setString(2, proveedor.getAddress());
            st.setString(3, proveedor.getEmail());
            st.setString(4, proveedor.getProductos_supplied());
            st.setString(5, proveedor.getPayment_conditions());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        
    }
    
    @Override
    public void modificar(Proveedores proveedor) throws Exception{
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE proveedores SET name = ?, address = ?, email = ?, productos_supplied = ?, payment_conditions = ? WHERE id = ?");
            st.setString(1, proveedor.getName());
            st.setString(2, proveedor.getAddress());
            st.setString(3, proveedor.getEmail());
            st.setString(4, proveedor.getProductos_supplied());
            st.setString(5, proveedor.getPayment_conditions());
            st.setInt(6, proveedor.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }
    
    
    @Override
    public void eliminar(int proveedorId) throws Exception{
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM proveedores WHERE id = ?;");
            st.setInt(1, proveedorId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }
    
    @Override
    public List<Proveedores> listar(String name) throws Exception{
        List<Proveedores> lista = null;
        try {
            this.Conectar();
            String Query = name.isEmpty() ? "SELECT * FROM proveedores;" : "SELECT * FROM proveedores WHERE name LIKE '%" + name + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Proveedores proveedor = new Proveedores();
                proveedor.setId(rs.getInt("id"));
                proveedor.setName(rs.getString("name"));
                proveedor.setAddress(rs.getString("address"));
                proveedor.setEmail(rs.getString("email"));
                proveedor.setProductos_supplied(rs.getString("productos_supplied"));
                proveedor.setPayment_conditions(rs.getString("payment_conditions"));
                lista.add(proveedor);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }
    
    @Override
    public Proveedores getProveedorById(int proveedorId) throws Exception{
        Proveedores proveedor = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM proveedores WHERE id = ? LIMIT 1;");
            st.setInt(1, proveedorId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                proveedor = new Proveedores();
                proveedor.setId(rs.getInt("id"));
                proveedor.setName(rs.getString("name"));
                proveedor.setAddress(rs.getString("address"));
                proveedor.setEmail(rs.getString("email"));
                proveedor.setProductos_supplied(rs.getString("productos_supplied"));
                proveedor.setPayment_conditions(rs.getString("payment_conditions"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return proveedor;
    }
    
}
