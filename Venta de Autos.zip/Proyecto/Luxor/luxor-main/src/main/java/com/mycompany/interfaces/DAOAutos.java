package com.mycompany.interfaces;

import com.mycompany.models.Autos;
import java.util.List;

public interface DAOAutos {
    public void registrar(Autos auto) throws Exception;
    public void modificar(Autos auto) throws Exception;
    public void eliminar(int autoId) throws Exception;
    public List<Autos> listar(String title) throws Exception;
    public Autos getAutoById(int autoId) throws Exception;
}
