package com.mycompany.luxor;

import com.mycompany.db.Database;
import com.mycompany.models.Clients;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOClients;

public class DAOClientsImpl extends Database implements DAOClients {

    @Override
    public void registrar(Clients client) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO clients(name, last_name_p, last_name_m, domicilio, tel) VALUES(?,?,?,?,?);");
            st.setString(1, client.getName());
            st.setString(2, client.getLast_name_p());
            st.setString(3, client.getLast_name_m());
            st.setString(4, client.getDomicilio());
            st.setString(5, client.getTel());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Clients client) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE clients SET name = ?, last_name_p = ?, last_name_m = ?, domicilio = ?, tel = ? WHERE id = ?");
            st.setString(1, client.getName());
            st.setString(2, client.getLast_name_p());
            st.setString(3, client.getLast_name_m());
            st.setString(4, client.getDomicilio());
            st.setString(5, client.getTel());
            st.setInt(6, client.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(int clientId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM clients WHERE id = ?;");
            st.setInt(1, clientId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Clients> listar(String name) throws Exception {
        List<Clients> lista = null;
        try {
            this.Conectar();
            String Query = name.isEmpty() ? "SELECT * FROM clients;" : "SELECT * FROM clients WHERE name LIKE '%" + name + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Clients client = new Clients();
                client.setId(rs.getInt("id"));
                client.setName(rs.getString("name"));
                client.setLast_name_p(rs.getString("last_name_p"));
                client.setLast_name_m(rs.getString("last_name_m"));
                client.setDomicilio(rs.getString("domicilio"));
                client.setTel(rs.getString("tel"));
                lista.add(client);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Clients getClientById(int clientId) throws Exception {
        Clients client = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM clients WHERE id = ? LIMIT 1;");
            st.setInt(1, clientId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                client = new Clients();
                client.setId(rs.getInt("id"));
                client.setName(rs.getString("name"));
                client.setLast_name_p(rs.getString("last_name_p"));
                client.setLast_name_m(rs.getString("last_name_m"));
                client.setDomicilio(rs.getString("domicilio"));
                client.setTel(rs.getString("tel"));
                client.setSanctions(rs.getInt("sanctions"));
                client.setSanc_money(rs.getInt("sanc_money"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return client;
    }

    
}
