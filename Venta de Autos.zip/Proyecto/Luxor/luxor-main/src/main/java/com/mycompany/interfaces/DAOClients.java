package com.mycompany.interfaces;

import com.mycompany.models.Clients;
import java.util.List;

public interface DAOClients {
    public void registrar(Clients client) throws Exception;
    public void modificar(Clients client) throws Exception;
    public void eliminar(int clientId) throws Exception;
    public List<Clients> listar(String name) throws Exception;
    public Clients getClientById(int clientId) throws Exception;
}