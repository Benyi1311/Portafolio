package com.mycompany.luxor;

import com.mycompany.interfaces.DAOUsuarios;
import com.mycompany.db.Database;
import com.mycompany.models.Usuarios;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class DAOUsuariosImpl extends Database implements DAOUsuarios {
    @Override
    public boolean validarUsuario(String username, String password) {
        boolean isValid = false;
        try {
            Conectar();
            String sql = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
            PreparedStatement ps = conexion.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                isValid = true; 
            }
            Cerrar();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isValid;
    }
    
    @Override
    public void registrar(Usuarios usuario) throws Exception{
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO usuarios(username, password) VALUES(?,?);");
            st.setString(1, usuario.getUsername());
            st.setString(2, usuario.getPassword());

            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }   
    }
    
    @Override
    public void modificar(Usuarios usuario) throws Exception{
            try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE usuarios SET username = ?, password = ? WHERE id = ?");
            st.setString(1, usuario.getUsername());
            st.setString(2, usuario.getPassword());
            st.setInt(3, usuario.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }    
    }
    
    @Override
    public void eliminar(int usuarioId) throws Exception{
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM usuarios WHERE id = ?;");
            st.setInt(1, usuarioId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }        
    }
    
    @Override
    public List<Usuarios> listar(String username) throws Exception{
        List<Usuarios> lista = null;
        try {
            this.Conectar();
            String Query = username.isEmpty() ? "SELECT * FROM usuarios;" : "SELECT * FROM usuarios WHERE username LIKE '%" + username + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Usuarios usuario = new Usuarios();
                usuario.setId(rs.getInt("id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));
                lista.add(usuario);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;        
    }
    
    @Override
    public Usuarios getUsuarioById(int usuarioId) throws Exception{
        Usuarios usuario = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM usuarios WHERE id = ? LIMIT 1;");
            st.setInt(1, usuarioId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                usuario = new Usuarios();
                usuario.setId(rs.getInt("id"));
                usuario.setUsername(rs.getString("username"));
                usuario.setPassword(rs.getString("password"));

            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return usuario;
    }
}
