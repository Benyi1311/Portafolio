package com.mycompany.interfaces;

import com.mycompany.models.Autos;
import com.mycompany.models.Buys;
import com.mycompany.models.Clients;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public interface DAOBuys {
    public void registrar(Buys buy) throws Exception;
    public void modificar(Buys buy) throws Exception;
    public Buys getBuy(Clients client, Autos auto) throws Exception;
    public List<Buys> listar() throws Exception; 
    public float obtenerVentasDia() throws Exception;
    public float obtenerVentasSemana() throws Exception;
    public float obtenerVentasMes() throws Exception;
    public float obtenerVentasAnio() throws Exception;
}
