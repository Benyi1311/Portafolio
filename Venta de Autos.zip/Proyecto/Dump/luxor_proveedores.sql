-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: luxor
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `productos_supplied` text,
  `payment_conditions` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Volkswagen Group','Av.Javier Prado 321','Volkswagen@gmail.com','Autos y accesorios','Pago a 30 días'),(2,'Mercedez-Benz Group','Av.Colonial 105','Mercedez-Benz@gmail.com','Autos y accesorios','Al contado'),(3,'Toyota Motor Corp','Av. La Marina 450','toyota@gmail.com','Autos','Pago a 15 días'),(4,'Honda Motors','Jr. Los Jardines 110','honda@gmail.com','Motos,autos y accesorios','Al contado'),(5,'Ford Company','Calle Industrial 89','ford@gmail.com','Autos','Crédito bancario'),(6,'Tesla Motors','Av. Tecnológica 200','tesla@gmail.com','Autos Eléctricos','Pago a 15 días'),(7,'Ferrari S.p.A','Calle Italia 55','ferrari@gmail.com','Autos de lujo','Pago a 60 días'),(8,'Automobili Lamborghini','Vía Sant\'Agata 12','lamborghini@gmail.com','Autos de lujo','Al contado'),(9,'Audi AG','Av. Alemana 300','audi@gmail.com','Autos','Pago a 30 días'),(10,'Porsche AG','Calle Stuttgart 77','porsche@gmail.com','Autos de lujo','Pago a 15 días'),(11,'BMW Group','Av. Bávara 450','bmw@gmail.com','Autos','Pago a 30 días'),(12,'Chevrolet','Av. Americana 678','chevrolet@gmail.com','Autos','Crédito bancario');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-05 20:56:53
