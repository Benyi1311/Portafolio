-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: luxor
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autos`
--

DROP TABLE IF EXISTS `autos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marca` varchar(255) NOT NULL,
  `modelo` varchar(255) NOT NULL,
  `año` varchar(255) NOT NULL,
  `motor` varchar(255) NOT NULL,
  `combustible` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `transmision` varchar(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `kilometraje` float NOT NULL,
  `precio` float NOT NULL,
  `disponible` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autos`
--

LOCK TABLES `autos` WRITE;
/*!40000 ALTER TABLE `autos` DISABLE KEYS */;
INSERT INTO `autos` VALUES (1,'Audi','TT','2022','2.0L TFSI','Gasolina','Rojo','Automática','Coupé deportivo de lujo con diseño innovador y excelente rendimiento.',12000,45000,4),(2,'Ferrari','Enzo','2018','6.0L V12','Gasolina','Rojo','Automática Secuencial','Superdeportivo de edición limitada',5000,2500000,3),(3,'Tesla','Model S','2023','Eléctrico Dual Motor','Eléctrico','Blanco Perla','Automática','Sedán de lujo totalmente eléctrico',0,200000,5),(4,'Ford','Mustang GT','2020','5.0L V8','Gasolina','Azul Racing','Manual','motor de alto rendimiento',0,80000,5),(5,'BMW','X5','2022','3.0L TwinPower Turbo','Gasolina','Negro Safiro','Automática','SUV de lujo con amplio espacio interior',0,110000,1),(6,'Lamborghini','Huracán EVO','2023','5.2L V10','Gasolina','Verde Mantis','Automática DCT','Superdeportivo con tracción integral,',3500,1100000,3),(7,'Audi','R8','2021','5.2L V10','Gasolina','Plata Metalizado','Automática DCT','Superdeportivo de alto rendimiento con tracción quattro',0,300000,5),(9,'Toyota','Corolla','2021','1.8L Hybrid','Híbrido','Gris Metálico','Automática CVT','Sedán compacto eficiente',10000,50000,5),(10,'Porsche','911 Carrera','2020','3.0L Flat-6 Turbo','Gasolina','Amarillo Racing','Automática PDK','Coupé deportivo de lujo',0,450000,5),(11,'Mercedes-Benz','Clase G','2022','4.0L V8 Biturbo','Gasolina','Negro Mate','Automática 9G-Tronic','SUV todoterreno de lujo con capacidades extremas',0,250000,5),(13,'BMW','Serie 3','2021','2.0L TwinPower Turbo','Gasolina','Azul Marino','Automática','Sedán deportivo compacto',22000,80000,5),(14,'Ford','F-150 Raptor','2023','3.5L V6 EcoBoost','Gasolina','Gris Oscuro','Automática','Camioneta de alto desempeño',0,100000,8),(15,'Chevrolet','Camaro ZL1','2022','6.2L V8 Supercharged','Gasolina','Naranja Solar','Manual','Carro de alto rendimiento con diseño agresivo',0,120000,8),(16,'Lamborghini','Aventador SVJ','2023','6.5L V12','Gasolina','Blanco Perla','Automática ISR','Superdeportivo de edición limitada',2000,1000000,6),(17,'Tesla','Model S Plaid','2023','Eléctrico (Tri-Motor)','Eléctrico','Rojo Medianoche','Automática EV','Sedán eléctrico ultra rápido',0,800000,8),(18,'Toyota','Supra GR','2022','3.0L Twin-Turbo I6','Gasolina','Plata Espejo','Automática','Coupé deportivo japonés',0,100000,7),(19,'Chevrolet','Corvette Stingray','2023','6.2L V8','Gasolina','Azul Eléctrico','Automática','Coupé deportivo estadounidense',0,120000,5),(20,'Ferrari','812 Superfast','2023','6.5L V12','Gasolina','Rojo Rosso Corsa','Automática DCT','Superdeportivo italiano',3000,1300000,8),(21,'Porsche','911 Turbo S','2023','3.8L Flat-6 Twin-Turbo','Gasolina','Plata','Automática PDK',' Coupé alemán',0,800000,8),(22,'Mercedes-Benz','AMG GT Black Series','2023','4.0L V8 Biturbo','Gasolina','Naranja','Automática AMG','Superdeportivo alemán',0,800000,8),(23,'Lamborghini','Huracán EVO','2023','5.2L V10','Gasolina','Verde Mantis','Automática LDF','Superdeportivo italiano',0,1250000,5);
/*!40000 ALTER TABLE `autos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-05 20:56:53
